import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import HttpRequest.HttpRequest;

public class Main2014302580248 {
	public static void main(String[] args) throws IOException{
	String urlString = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie";
    
    String filePath = "teacher.html";
    File input = new File(filePath);
    HttpRequest response = HttpRequest.get(urlString);
    response.receive(input);
    output(input);
	}
	
	public static void output(File input) throws IOException{
        Document doc = Jsoup.parse(input,"UTF-8");
        File file = new File("newteacher.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file,true));
		Element mytable = doc.getElementsByTag("body").first();
		Elements h = mytable.getElementsByTag("h1");
		if(!h.isEmpty())
			for(Element a:h)
			{String c = a.text().trim();
			bufferedWriter.write(c + "\r\n");
			System.out.println(c);
			}
		//Elements p = mytable.getElementsByTag("P");
		
		Elements teacher = mytable.select("p:matches([a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z]$*)");
					
		String[] head = teacher.text().split(" ");
		for(int i = 0;i < head.length;i++)
		{
		bufferedWriter.write(head[i] + "\r\n");
		System.out.println(head[i]);
		}
			
		bufferedWriter.close();
	}
}


